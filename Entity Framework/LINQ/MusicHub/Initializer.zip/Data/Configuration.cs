﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-E8HCIGG\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
