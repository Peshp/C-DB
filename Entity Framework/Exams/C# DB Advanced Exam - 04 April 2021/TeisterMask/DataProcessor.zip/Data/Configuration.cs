﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-F7D2TT2\SQLEXPRESS;Database=TeisterMaskExam;Integrated Security=True;Encrypt=False";
    }
}
